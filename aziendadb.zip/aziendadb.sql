CREATE DATABASE AziendaDB;
GO

USE AziendaDB;
GO

CREATE TABLE IMPIEGO (
    ImpiegoID INT PRIMARY KEY,
    Descrizione NVARCHAR(100)
);


CREATE TABLE IMPIEGATO (
    ImpiegatoID INT PRIMARY KEY,
    Nome NVARCHAR(50),
    Cognome NVARCHAR(50),
    Et� INT,
    RedditoMensile DECIMAL(10, 2),
    DetrazioneFiscale BIT,
    DataAssunzione DATE,
    ImpiegoID INT,
    FOREIGN KEY (ImpiegoID) REFERENCES IMPIEGO (ImpiegoID)
);

INSERT INTO IMPIEGO (ImpiegoID, Descrizione)
VALUES
    (1, 'Manager'),
    (2, 'Sviluppatore'),
    (3, 'Contabile'),
    (4, 'Assistente');


INSERT INTO IMPIEGATO (ImpiegatoID, Nome, Cognome, Et�, RedditoMensile, DetrazioneFiscale, DataAssunzione, ImpiegoID)
VALUES
    (1, 'John', 'Doe', 30, 1000.00, 1, '2020-01-15', 1),
    (2, 'Jane', 'Smith', 28, 850.50, 0, '2019-05-10', 2),
    
    (3, 'Alice', 'Johnson', 35, 1200.00, 1, '2018-08-20', 3);
    (4, 'Raffaele', 'Ianniello', 27, 4367.00, 1, '2021-12-20', 3);

    (5, 'Gianluigi', 'Buffon', 45, 8900.00, 0, '2017-03-23', 3);

    (6, 'Alessandro', 'Del Piero', 48, 3210.00, 1, '2020-11-12', 3);
	(7, 'Edgar', 'Davids', 35, 4530.00, 1, '2016-05-30', 3);

	-- a. Visualizza tutti gli impiegati oltre i 29 anni
SELECT * FROM IMPIEGATO WHERE Et� > 29;

-- b. Visualizza tutti gli impiegati con un reddito di almeno 800 euro mensili
SELECT * FROM IMPIEGATO WHERE RedditoMensile >= 800;

-- c. Visualizza tutti gli impiegati che posseggono la detrazione fiscale
SELECT * FROM IMPIEGATO WHERE DetrazioneFiscale = 1;

-- d. Visualizza tutti gli impiegati che non posseggono la detrazione fiscale
SELECT * FROM IMPIEGATO WHERE DetrazioneFiscale = 0;

-- e. Visualizza tutti gli impiegati cui il cognome cominci con una lettera G in ordine alfabetico
SELECT * FROM IMPIEGATO WHERE Cognome LIKE 'G%' ORDER BY Cognome;

-- f. Visualizza il numero totale degli impiegati registrati nella base dati
SELECT COUNT(*) AS NumeroImpiegati FROM IMPIEGATO;

-- g. Visualizza il totale dei redditi mensili di tutti gli impiegati
SELECT SUM(RedditoMensile) AS TotaleRedditiMensili FROM IMPIEGATO;

-- h. Visualizza la media dei redditi mensili di tutti gli impiegati
SELECT AVG(RedditoMensile) AS MediaRedditiMensili FROM IMPIEGATO;

-- i. Visualizza l'importo del reddito mensile maggiore
SELECT MAX(RedditoMensile) AS RedditoMensileMaggiore FROM IMPIEGATO;

-- j. Visualizza l'importo del reddito mensile minore
SELECT MIN(RedditoMensile) AS RedditoMensileMinore FROM IMPIEGATO;

-- k. Visualizza gli impiegati assunti dall'01/01/2007 all'01/01/2008
SELECT * FROM IMPIEGATO WHERE DataAssunzione BETWEEN '2007-01-01' AND '2008-01-01';

-- l. Query parametrica per identificare il tipo di impiego
CREATE PROCEDURE TrovaImpiegatiPerTipoImpiego
    @TipoImpiego NVARCHAR(100)
AS
BEGIN
    SELECT I.* 
    FROM IMPIEGATO I
    INNER JOIN IMPIEGO T ON I.ImpiegoID = T.ImpiegoID
    WHERE T.Descrizione = @TipoImpiego;
END;

-- m. Visualizza l'et� media dei lavoratori all'interno dell'azienda
SELECT AVG(Et�) AS Et�MediaLavoratori FROM IMPIEGATO;


-- a. Memorizzazione di un nuovo impiegato
CREATE PROCEDURE InserisciImpiegato
    @Nome NVARCHAR(50),
    @Cognome NVARCHAR(50),
    @Et� INT,
    @RedditoMensile DECIMAL(10, 2),
    @DetrazioneFiscale BIT,
    @DataAssunzione DATE,
    @ImpiegoID INT
AS
BEGIN
    INSERT INTO IMPIEGATO (Nome, Cognome, Et�, RedditoMensile, DetrazioneFiscale, DataAssunzione, ImpiegoID)
    VALUES (@Nome, @Cognome, @Et�, @RedditoMensile, @DetrazioneFiscale, @DataAssunzione, @ImpiegoID);
END;

-- b. Aggiornamento di un impiegato
CREATE PROCEDURE AggiornaImpiegato
    @ImpiegatoID INT,
    @Nome NVARCHAR(50),
    @Cognome NVARCHAR(50),
    @Et� INT,
    @RedditoMensile DECIMAL(10, 2),
    @DetrazioneFiscale BIT,
    @DataAssunzione DATE,
    @ImpiegoID INT
AS
BEGIN
    UPDATE IMPIEGATO
    SET Nome = @Nome,
        Cognome = @Cognome,
        Et� = @Et�,
        RedditoMensile = @RedditoMensile,
        DetrazioneFiscale = @DetrazioneFiscale,
        DataAssunzione = @DataAssunzione,
        ImpiegoID = @ImpiegoID
    WHERE ImpiegatoID = @ImpiegatoID;
END;

-- c. Eliminazione di un impiegato
CREATE PROCEDURE EliminaImpiegato
    @ImpiegatoID INT
AS
BEGIN
    DELETE FROM IMPIEGATO WHERE ImpiegatoID = @ImpiegatoID;
END;